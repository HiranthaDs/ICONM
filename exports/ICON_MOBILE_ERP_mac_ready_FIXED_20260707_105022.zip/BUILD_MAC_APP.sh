#!/bin/zsh
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

echo "Building ICON MOBILE ERP macOS .app"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is not installed. Install Python 3 for macOS first."
  exit 1
fi

python3 -m venv .venv-build
source .venv-build/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip install -r requirements-mac-build.txt

python diagnose.py

rm -rf build dist
pyinstaller --noconfirm --clean IMERP_V_GM.spec

APP_PATH="dist/ICON MOBILE ERP.app"
if [ -d "$APP_PATH" ]; then
  if command -v codesign >/dev/null 2>&1; then
    codesign --force --deep --sign - "$APP_PATH" || true
  fi
  if command -v hdiutil >/dev/null 2>&1; then
    rm -f "dist/ICON_MOBILE_ERP_macOS.dmg"
    hdiutil create -volname "ICON MOBILE ERP" -srcfolder "$APP_PATH" -ov -format UDZO "dist/ICON_MOBILE_ERP_macOS.dmg"
  fi
  echo ""
  echo "Build complete:"
  echo "  $APP_PATH"
  echo "  dist/ICON_MOBILE_ERP_macOS.dmg"
else
  echo "Build failed: .app was not created."
  exit 1
fi
